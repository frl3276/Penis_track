# APEX VELOCITY 3D — Pixel 10 Pro APK Project

Готовый Android WebView проект со встроенной автосборкой APK через GitHub Actions.

## Быстрая сборка APK
1. Загрузите содержимое этой папки в новый репозиторий на GitHub (убедитесь, что файл `.github/workflows/build-apk.yml` тоже загружен).
2. Перейдите во вкладку **Actions** в репозитории.
3. Откройте последний запуск **Build Apex Velocity 3D APK**.
4. Через 1–2 минуты скачайте артефакт **ApexVelocity3D-Pixel10Pro-APK** внизу страницы.
5. Распакуйте ZIP, скиньте `ApexVelocity3D-Pixel10Pro.apk` на Pixel 10 Pro и установите.
