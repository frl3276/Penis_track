# APEX VELOCITY 3D v3.0 — Ultimate Edition

Универсальный Android WebView проект (Tensor / Snapdragon / MediaTek) со встроенной сборкой APK.
