package com.apexvelocity.racing;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.view.Display;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "apex_velocity_save_v3";
    private WebView webView;
    private Vibrator vibrator;
    private SharedPreferences prefs;
    private long lastBackPressMs = 0L;
    private int safeTop = 0, safeRight = 0, safeBottom = 0, safeLeft = 0;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        initVibrator();
        configureWindow();
        restoreSavedOrientation();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setVerticalScrollBarEnabled(false);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setTextZoom(100); // Prevents Android system font-size scaling from breaking HUD layout!

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pushSafeInsetsToJs();
            }
        });

        setContentView(webView);
        setupCutoutInsetsListener();
        enableImmersiveMode();

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void initVibrator() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            if (vm != null) vibrator = vm.getDefaultVibrator();
        } else {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
    }

    private void configureWindow() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        try {
            Display display = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
                    ? getDisplay()
                    : getWindowManager().getDefaultDisplay();
            if (display != null) {
                Display.Mode current = display.getMode();
                Display.Mode best = current;
                for (Display.Mode m : display.getSupportedModes()) {
                    if (m.getPhysicalWidth() == current.getPhysicalWidth()
                            && m.getPhysicalHeight() == current.getPhysicalHeight()
                            && m.getRefreshRate() > best.getRefreshRate()) {
                        best = m;
                    }
                }
                lp.preferredDisplayModeId = best.getModeId();
            }
        } catch (Exception ignored) {
        }

        getWindow().setAttributes(lp);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void enableImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            View decor = getWindow().getDecorView();
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
            );
        }
    }

    private void setupCutoutInsetsListener() {
        View root = getWindow().getDecorView();
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            float density = getResources().getDisplayMetrics().density;
            if (density <= 0f) density = 1f;
            int t = 0, r = 0, b = 0, l = 0;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets cut = insets.getInsets(WindowInsets.Type.displayCutout());
                t = Math.round(cut.top / density);
                r = Math.round(cut.right / density);
                b = Math.round(cut.bottom / density);
                l = Math.round(cut.left / density);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                DisplayCutout dc = insets.getDisplayCutout();
                if (dc != null) {
                    t = Math.round(dc.getSafeInsetTop() / density);
                    r = Math.round(dc.getSafeInsetRight() / density);
                    b = Math.round(dc.getSafeInsetBottom() / density);
                    l = Math.round(dc.getSafeInsetLeft() / density);
                }
            }

            // Guarantee small rounded-corner / gesture-edge padding on modern phones
            safeTop = Math.max(t, 6);
            safeRight = Math.max(r, 8);
            safeBottom = Math.max(b, 8);
            safeLeft = Math.max(l, 8);

            pushSafeInsetsToJs();
            return insets;
        });
    }

    private void pushSafeInsetsToJs() {
        if (webView == null) return;
        final String js = "if(window.applyNativeInsets){window.applyNativeInsets("
                + safeTop + "," + safeRight + "," + safeBottom + "," + safeLeft + ");}";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void restoreSavedOrientation() {
        String mode = prefs.getString("orientation_mode", "auto");
        applyOrientation(mode);
    }

    private void applyOrientation(String mode) {
        if ("landscape".equals(mode)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else if ("portrait".equals(mode)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        enableImmersiveMode();
        if (webView != null) {
            webView.postDelayed(() -> {
                pushSafeInsetsToJs();
                webView.evaluateJavascript("if(window.forceGameResize){window.forceGameResize();}", null);
            }, 80);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enableImmersiveMode();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) {
            webView.evaluateJavascript("if(window.onAppPause){window.onAppPause();}", null);
            webView.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        enableImmersiveMode();
        if (webView != null) {
            webView.onResume();
            webView.evaluateJavascript("if(window.onAppResume){window.onAppResume();}", null);
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("window.onAndroidBack ? window.onAndroidBack() : 'exit'", result -> {
                if (result != null && result.contains("exit")) {
                    long now = System.currentTimeMillis();
                    if (now - lastBackPressMs < 2000) {
                        finish();
                    } else {
                        lastBackPressMs = now;
                        Toast.makeText(MainActivity.this, "Нажми «Назад» ещё раз для выхода", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void vibrate(int durationMs, int amplitude) {
            if (vibrator == null || !vibrator.hasVibrator()) return;
            try {
                int dur = Math.max(8, Math.min(durationMs, 300));
                int amp = Math.max(1, Math.min(amplitude, 255));
                vibrator.vibrate(VibrationEffect.createOneShot(dur, amp));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void saveData(String key, String value) {
            if (key == null || value == null) return;
            prefs.edit().putString(key, value).apply();
        }

        @JavascriptInterface
        public String loadData(String key) {
            if (key == null) return "";
            return prefs.getString(key, "");
        }

        @JavascriptInterface
        public void setOrientation(final String mode) {
            prefs.edit().putString("orientation_mode", mode).apply();
            runOnUiThread(() -> applyOrientation(mode));
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            return Build.MANUFACTURER + " " + Build.MODEL + " (" + Build.HARDWARE + ")";
        }
    }
}
