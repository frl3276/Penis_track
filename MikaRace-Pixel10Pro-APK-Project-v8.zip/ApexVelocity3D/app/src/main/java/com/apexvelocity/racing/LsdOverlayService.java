package com.apexvelocity.racing;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.PlaybackParams;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.Settings;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.Random;

public class LsdOverlayService extends Service {

    public static final String ACTION_START = "com.apexvelocity.racing.ACTION_START_LSD";
    public static final String ACTION_STOP  = "com.apexvelocity.racing.ACTION_STOP_LSD";

    private static final String PREFS_NAME = "apex_velocity_save_v3";
    private static final String CHANNEL_ID = "mikarace_lsd_overlay";
    private static final int NOTIF_ID = 7771;

    private static final String[] MIKA_LINES = new String[] {
            "Вась, СТОЙ!! Пожалуйста, брось наркотики!! Ты посмотри, как тебя жёстко кроет... 😭",
            "Я умоляю тебя, завязывай с этой дрянью! Даже рабочий стол поплыл!! ✝",
            "Хватит жрать марки, очнись!! Мне страшно за тебя, выключи этот трип, прошу!!",
            "Куда ты вышел из игры?! Меня теперь даже в других приложениях глючит, завязывай!!",
            "Я плачу из-за тебя!! Поймай эту кнопку и вернись в реальность, умоляю... 😭",
            "Мне плевать на лифчики и тачки — просто брось эту отраву!! Лови кнопку и вырубай!!",
            "Пожалуйста, услышь меня!! У тебя уже весь телефон поплыл, бросай наркоту!! ✝😭",
            "Я не хочу смотреть, как тебя так кроет... прошу, выключи трип прямо сейчас!!"
    };

    private static final String[] BTN_TAUNTS = new String[] {
            "🍄 ХУЙ ПОПАДЁШЬ!",
            "🍄 МИМО!",
            "🍄 ЛОВИ МЕНЯ!",
            "🍄 АХАХА НЕ УСПЕЛ!"
    };

    private static final int[] AUDIO_OFFSETS_MS = new int[] {
            0, 1050, 2150, 3250, 4400, 5450
    };

    private WindowManager windowManager;
    private TripOverlayView tripView;
    private TextView escapeBtn;
    private WindowManager.LayoutParams btnParams;
    private SharedPreferences prefs;
    private Vibrator vibrator;
    private MediaPlayer mediaPlayer;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random rng = new Random();

    private boolean running = false;
    private long lastFrameNs = 0L;
    private float tripTime = 0f;
    private float begTimer = 0f;

    // Flying Escape Button physics
    private float btnX = 180f, btnY = 300f;
    private float btnVx = 420f, btnVy = -340f;
    private float btnPhase = 0f;
    private int btnHits = 0;
    private float tauntTimer = 0f;

    // Flying Goth Mika physics
    private float mikaX = 120f, mikaY = 420f;
    private float mikaVx = -230f, mikaVy = 195f;
    private float mikaPhase = 1.4f;
    private float mikaJiggle = 0f;
    private int lastLineIdx = -1;
    private int lastAudioIdx = -1;
    private String currentLine = MIKA_LINES[0];

    private Bitmap mikaBitmap;
    private float density = 3f;

    private final Runnable pauseAudioTask = new Runnable() {
        @Override
        public void run() {
            try {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    mediaPlayer.pause();
                }
            } catch (Exception ignored) {
            }
        }
    };

    private final Runnable frameLoop = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            long nowNs = System.nanoTime();
            float dt = (lastFrameNs == 0L) ? 0.016f : (nowNs - lastFrameNs) / 1_000_000_000f;
            lastFrameNs = nowNs;
            if (dt < 0.001f) dt = 0.016f;
            if (dt > 0.05f) dt = 0.05f;

            stepSimulation(dt);
            handler.postDelayed(this, 16);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        density = getResources().getDisplayMetrics().density;
        if (density <= 0f) density = 2.5f;

        initVibrator();
        loadMikaBitmap();
        initMediaPlayer();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            disableLsdAndStop(false);
            return START_NOT_STICKY;
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        startForegroundSafely();

        if (!running) {
            running = true;
            lastFrameNs = System.nanoTime();
            btnHits = 0;
            begTimer = 0f;
            attachOverlays();
            triggerMikaBeg();
            handler.post(frameLoop);
        }

        return START_STICKY;
    }

    private void startForegroundSafely() {
        createNotificationChannel();
        Notification notif = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIF_ID, notif);
        }
    }

    private void createNotificationChannel() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID,
                "MikaRace — Режим ЛСД",
                NotificationManager.IMPORTANCE_LOW
        );
        ch.setDescription("Активный психоделический оверлей Мики поверх всех приложений");
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 1, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent stopIntent = new Intent(this, LsdOverlayService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 2, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Action stopAction = new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel,
                "ВЫКЛ ЛСД",
                stopPi
        ).build();

        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("🍄 MikaRace — Режим ЛСД активен")
                .setContentText("Поймай летающую кнопку или нажми ВЫКЛ ЛСД здесь")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(openPi)
                .addAction(stopAction)
                .setOngoing(true)
                .build();
    }

    private void initVibrator() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            if (vm != null) vibrator = vm.getDefaultVibrator();
        } else {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
    }

    private void vibrateShort(int ms, int amp) {
        if (vibrator == null || !vibrator.hasVibrator()) return;
        try {
            vibrator.vibrate(VibrationEffect.createOneShot(ms, Math.max(1, Math.min(255, amp))));
        } catch (Exception ignored) {
        }
    }

    private void loadMikaBitmap() {
        try (InputStream is = getAssets().open("mika_goth.webp")) {
            mikaBitmap = BitmapFactory.decodeStream(is);
        } catch (Exception e) {
            try (InputStream is2 = getAssets().open("mika_normal.webp")) {
                mikaBitmap = BitmapFactory.decodeStream(is2);
            } catch (Exception ignored) {
            }
        }
    }

    private void initMediaPlayer() {
        try {
            AssetFileDescriptor afd = getAssets().openFd("zvuki_orgazm.mp3");
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
            );
            mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mediaPlayer.prepare();
            mediaPlayer.setVolume(0.9f, 0.9f);
        } catch (Exception e) {
            mediaPlayer = null;
        }
    }

    private void playDistortedMikaClip() {
        if (!prefs.getBoolean("waifu_voice", true)) return;
        if (mediaPlayer == null) return;
        try {
            handler.removeCallbacks(pauseAudioTask);
            int idx = rng.nextInt(AUDIO_OFFSETS_MS.length);
            if (AUDIO_OFFSETS_MS.length > 1 && idx == lastAudioIdx) {
                idx = (idx + 1) % AUDIO_OFFSETS_MS.length;
            }
            lastAudioIdx = idx;
            int startMs = AUDIO_OFFSETS_MS[idx];
            int durMs = 920 + rng.nextInt(320);

            try {
                PlaybackParams pp = mediaPlayer.getPlaybackParams();
                pp.setSpeed(0.66f + rng.nextFloat() * 0.14f);
                pp.setPitch(0.72f + rng.nextFloat() * 0.14f);
                mediaPlayer.setPlaybackParams(pp);
            } catch (Exception ignored) {
            }

            mediaPlayer.seekTo(startMs);
            mediaPlayer.start();
            handler.postDelayed(pauseAudioTask, durMs);
        } catch (Exception ignored) {
        }
    }

    private void triggerMikaBeg() {
        int idx = rng.nextInt(MIKA_LINES.length);
        if (MIKA_LINES.length > 1 && idx == lastLineIdx) {
            idx = (idx + 1) % MIKA_LINES.length;
        }
        lastLineIdx = idx;
        currentLine = MIKA_LINES[idx];
        mikaJiggle = 1.0f;
        playDistortedMikaClip();
    }

    private void attachOverlays() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int sw = Math.max(300, dm.widthPixels);
        int sh = Math.max(300, dm.heightPixels);

        btnX = sw * 0.35f;
        btnY = sh * 0.28f;
        btnVx = 260f * density;
        btnVy = -210f * density;

        mikaX = sw * 0.18f;
        mikaY = sh * 0.48f;
        mikaVx = -115f * density;
        mikaVy = 95f * density;

        // 1. Fullscreen Non-Touchable Trip + Flying Mika Canvas
        tripView = new TripOverlayView(this);
        WindowManager.LayoutParams tripParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        tripParams.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            tripParams.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        windowManager.addView(tripView, tripParams);

        // 2. Interactive Flying Escape Button
        escapeBtn = new TextView(this);
        escapeBtn.setText("🍄 ВЫКЛ ЛСД");
        escapeBtn.setTextColor(Color.WHITE);
        escapeBtn.setTextSize(13f);
        escapeBtn.setTypeface(Typeface.DEFAULT_BOLD);
        int padH = Math.round(14f * density);
        int padV = Math.round(9f * density);
        escapeBtn.setPadding(padH, padV, padH, padV);
        escapeBtn.setShadowLayer(6f, 0f, 2f, Color.BLACK);

        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[] { 0xEE050008, 0xEEFF00AA, 0xEE00FF66 }
        );
        bg.setCornerRadius(999f);
        bg.setStroke(Math.round(2f * density), Color.WHITE);
        escapeBtn.setBackground(bg);

        btnParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        btnParams.gravity = Gravity.TOP | Gravity.START;
        btnParams.x = Math.round(btnX);
        btnParams.y = Math.round(btnY);

        escapeBtn.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                handleEscapeTap(event.getRawX(), event.getRawY());
                return true;
            }
            return false;
        });

        windowManager.addView(escapeBtn, btnParams);
    }

    private void handleEscapeTap(float tapX, float tapY) {
        btnHits++;
        // First hit always dodges & teleports; 2nd hit 45% dodge; 3rd hit always catches!
        if (btnHits == 1 || (btnHits == 2 && rng.nextFloat() < 0.45f)) {
            int sw = Math.max(400, tripView != null ? tripView.getWidth() : 1080);
            int sh = Math.max(400, tripView != null ? tripView.getHeight() : 1920);
            int bw = Math.max(180, escapeBtn != null ? escapeBtn.getWidth() : 260);
            int bh = Math.max(90, escapeBtn != null ? escapeBtn.getHeight() : 110);
            int maxX = Math.max(40, sw - bw - 30);
            int maxY = Math.max(80, sh - bh - 80);

            btnX = (tapX > sw * 0.5f)
                    ? (24f + rng.nextFloat() * (maxX * 0.35f))
                    : (maxX * 0.55f + rng.nextFloat() * (maxX * 0.4f));
            btnY = (tapY > sh * 0.5f)
                    ? (80f + rng.nextFloat() * (maxY * 0.32f))
                    : (maxY * 0.55f + rng.nextFloat() * (maxY * 0.35f));

            float spd = (240f + rng.nextFloat() * 140f) * density;
            double ang = rng.nextDouble() * Math.PI * 2.0;
            btnVx = (float) Math.cos(ang) * spd;
            btnVy = (float) Math.sin(ang) * spd;

            escapeBtn.setText(BTN_TAUNTS[rng.nextInt(BTN_TAUNTS.length)]);
            tauntTimer = 0.9f;
            vibrateShort(24, 175);
            triggerMikaBeg();
            return;
        }

        vibrateShort(50, 220);
        disableLsdAndStop(true);
    }

    private void disableLsdAndStop(boolean showToast) {
        prefs.edit()
                .putBoolean("lsd_active", false)
                .putBoolean("lsd_turned_off_externally", true)
                .apply();
        if (showToast) {
            Toast.makeText(this, "🍄 Режим ЛСД выключен! Мика рада ♡", Toast.LENGTH_SHORT).show();
        }
        stopSelf();
    }

    private void stepSimulation(float dt) {
        tripTime += dt;
        begTimer += dt;
        if (begTimer >= 4.0f) {
            begTimer = 0f;
            triggerMikaBeg();
        }
        if (mikaJiggle > 0f) {
            mikaJiggle = Math.max(0f, mikaJiggle - dt * 2.1f);
        }

        int sw = (tripView != null && tripView.getWidth() > 0)
                ? tripView.getWidth()
                : getResources().getDisplayMetrics().widthPixels;
        int sh = (tripView != null && tripView.getHeight() > 0)
                ? tripView.getHeight()
                : getResources().getDisplayMetrics().heightPixels;

        // 1. Move Flying Escape Button
        if (escapeBtn != null && btnParams != null) {
            int bw = Math.max(Math.round(110f * density), escapeBtn.getWidth());
            int bh = Math.max(Math.round(38f * density), escapeBtn.getHeight());
            float padX = 12f * density;
            float padY = 36f * density;
            float maxX = Math.max(padX + 10f, sw - bw - padX);
            float maxY = Math.max(padY + 10f, sh - bh - padY);

            btnPhase += dt * 5.0f;
            btnVx += (float) Math.sin(btnPhase * 1.35f) * 320f * density * dt;
            btnVy += (float) Math.cos(btnPhase * 1.75f) * 320f * density * dt;

            float curSpd = (float) Math.hypot(btnVx, btnVy);
            if (curSpd < 1f) curSpd = 1f;
            float minSpd = 155f * density;
            float maxSpd = 315f * density;
            float clamped = Math.max(minSpd, Math.min(maxSpd, curSpd));
            btnVx = (btnVx / curSpd) * clamped;
            btnVy = (btnVy / curSpd) * clamped;

            btnX += btnVx * dt;
            btnY += btnVy * dt;

            if (btnX < padX) { btnX = padX; btnVx = Math.abs(btnVx); }
            if (btnX > maxX) { btnX = maxX; btnVx = -Math.abs(btnVx); }
            if (btnY < padY) { btnY = padY; btnVy = Math.abs(btnVy); }
            if (btnY > maxY) { btnY = maxY; btnVy = -Math.abs(btnVy); }

            if (tauntTimer > 0f) {
                tauntTimer -= dt;
                if (tauntTimer <= 0f) escapeBtn.setText("🍄 ВЫКЛ ЛСД");
            }

            btnParams.x = Math.round(btnX);
            btnParams.y = Math.round(btnY);
            escapeBtn.setRotation((float) Math.sin(tripTime * 10.0f) * 10f);
            try {
                windowManager.updateViewLayout(escapeBtn, btnParams);
            } catch (Exception ignored) {
            }
        }

        // 2. Move Flying Goth Mika
        float shortSide = Math.min(sw, sh);
        float mikaW = Math.max(115f * density, Math.min(165f * density, shortSide * 0.34f));
        float mikaH = mikaW * (540f / 357f);
        float mPadX = 8f * density;
        float mPadTop = 95f * density; // room for speech bubble above her!
        float mPadBot = 24f * density;
        float mMaxX = Math.max(mPadX + 10f, sw - mikaW - mPadX);
        float mMaxY = Math.max(mPadTop + 10f, sh - mikaH - mPadBot);

        mikaPhase += dt * 2.6f;
        mikaVx += (float) Math.cos(mikaPhase * 1.15f) * 110f * density * dt;
        mikaVy += (float) Math.sin(mikaPhase * 1.45f) * 110f * density * dt;

        float mSpd = (float) Math.hypot(mikaVx, mikaVy);
        if (mSpd < 1f) mSpd = 1f;
        float mClamp = Math.max(75f * density, Math.min(165f * density, mSpd));
        mikaVx = (mikaVx / mSpd) * mClamp;
        mikaVy = (mikaVy / mSpd) * mClamp;

        mikaX += mikaVx * dt;
        mikaY += mikaVy * dt;

        if (mikaX < mPadX) { mikaX = mPadX; mikaVx = Math.abs(mikaVx); }
        if (mikaX > mMaxX) { mikaX = mMaxX; mikaVx = -Math.abs(mikaVx); }
        if (mikaY < mPadTop) { mikaY = mPadTop; mikaVy = Math.abs(mikaVy); }
        if (mikaY > mMaxY) { mikaY = mMaxY; mikaVy = -Math.abs(mikaVy); }

        if (tripView != null) {
            tripView.updateState(mikaX, mikaY, mikaW, mikaH);
            tripView.invalidate();
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        try {
            if (mediaPlayer != null) {
                if (mediaPlayer.isPlaying()) mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception ignored) {
        }
        try {
            if (tripView != null && windowManager != null) {
                windowManager.removeView(tripView);
                tripView = null;
            }
        } catch (Exception ignored) {
        }
        try {
            if (escapeBtn != null && windowManager != null) {
                windowManager.removeView(escapeBtn);
                escapeBtn = null;
            }
        } catch (Exception ignored) {
        }
        if (mikaBitmap != null && !mikaBitmap.isRecycled()) {
            mikaBitmap.recycle();
            mikaBitmap = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // ==================== FULLSCREEN TRIP + FLYING GOTH MIKA CANVAS ====================
    private class TripOverlayView extends View {

        private final Paint rayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint wavePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bubbleBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bubbleStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint titlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        private final Path wavePath = new Path();
        private final Matrix shaderMatrix = new Matrix();
        private final RectF dstRect = new RectF();
        private final RectF bubbleRect = new RectF();

        private SweepGradient sweepGradient;
        private int lastW = 0, lastH = 0;

        private float mx = 100f, my = 300f, mw = 300f, mh = 450f;

        public TripOverlayView(Context context) {
            super(context);
            wavePaint.setStyle(Paint.Style.STROKE);
            wavePaint.setStrokeWidth(7f * density);

            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(14f * density);

            bubbleBgPaint.setStyle(Paint.Style.FILL);
            bubbleBgPaint.setColor(0xEA06000A);

            bubbleStrokePaint.setStyle(Paint.Style.STROKE);
            bubbleStrokePaint.setStrokeWidth(2.4f * density);

            titlePaint.setColor(0xFF00FF66);
            titlePaint.setTextSize(10.5f * density);
            titlePaint.setTypeface(Typeface.DEFAULT_BOLD);

            textPaint.setColor(Color.WHITE);
            textPaint.setTextSize(11.5f * density);
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        }

        public void updateState(float x, float y, float w, float h) {
            this.mx = x;
            this.my = y;
            this.mw = w;
            this.mh = h;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            if (w != lastW || h != lastH || sweepGradient == null) {
                lastW = w;
                lastH = h;
                int[] cols = new int[] {
                        0x4000FF66, 0x3A050008, 0x42FF00AA, 0x36FFFFFF,
                        0x4000FF66, 0x3A050008, 0x42FF00AA, 0x36FFFFFF,
                        0x4000FF66
                };
                sweepGradient = new SweepGradient(w * 0.5f, h * 0.5f, cols, null);
                rayPaint.setShader(sweepGradient);
            }

            // 1. Rotating Green / Black / Pink / White hypnotic rays
            shaderMatrix.reset();
            shaderMatrix.postRotate((tripTime * 48f) % 360f, w * 0.5f, h * 0.5f);
            sweepGradient.setLocalMatrix(shaderMatrix);
            rayPaint.setAlpha(155 + (int) (Math.sin(tripTime * 2.6f) * 38));
            canvas.drawRect(0, 0, w, h, rayPaint);

            // 2. Liquid melting horizontal sine waves across the screen
            int waveCount = 7;
            for (int i = 0; i < waveCount; i++) {
                wavePath.reset();
                float baseY = (h / (float) (waveCount + 1)) * (i + 1)
                        + (float) Math.sin(tripTime * 1.9f + i) * 28f * density;
                boolean green = (i % 2 == 0);
                wavePaint.setColor(green ? 0x5000FF66 : 0x52FF00AA);
                wavePaint.setStrokeWidth((4f + (i % 3) * 2.5f) * density);

                float stepX = Math.max(24f, w / 16f);
                for (float x = 0; x <= w + stepX; x += stepX) {
                    float y = baseY + (float) Math.sin(x * 0.014f + tripTime * (2.6f + i * 0.25f) + i) * 24f * density;
                    if (x == 0f) wavePath.moveTo(x, y);
                    else wavePath.lineTo(x, y);
                }
                canvas.drawPath(wavePath, wavePaint);
            }

            // 3. Pulsing Acid-Green & Hot-Pink Screen Border
            float pulse = 0.5f + 0.5f * (float) Math.sin(tripTime * 4.2f);
            borderPaint.setColor(pulse > 0.5f ? 0x9900FF66 : 0x99FF00AA);
            canvas.drawRect(0, 0, w, h, borderPaint);

            // 4. Flying Goth Mika + Jiggle + Neon Aura
            if (mikaBitmap != null && !mikaBitmap.isRecycled()) {
                float cx = mx + mw * 0.5f;
                float cy = my + mh * 0.5f;

                // Neon halo behind Mika
                glowPaint.setColor(pulse > 0.5f ? 0x44FF00AA : 0x4400FF66);
                canvas.drawCircle(cx, cy, mw * 0.58f, glowPaint);

                float jiggleScaleX = 1.0f + (float) Math.sin(mikaJiggle * Math.PI * 3.0) * 0.10f * mikaJiggle;
                float jiggleScaleY = 1.0f - (float) Math.sin(mikaJiggle * Math.PI * 3.0) * 0.10f * mikaJiggle;
                float tilt = (float) Math.sin(tripTime * 3.2f) * 9f + (mikaVx / (220f * density)) * 10f;

                canvas.save();
                canvas.translate(cx, cy);
                canvas.rotate(tilt);
                canvas.scale(jiggleScaleX, jiggleScaleY);
                dstRect.set(-mw * 0.5f, -mh * 0.5f, mw * 0.5f, mh * 0.5f);
                canvas.drawBitmap(mikaBitmap, null, dstRect, bmpPaint);
                canvas.restore();
            }

            // 5. Attached Speech Bubble (always clamped inside screen bounds!)
            int bubbleMaxW = Math.round(Math.min(w * 0.68f, 225f * density));
            int innerPad = Math.round(9f * density);
            int textW = Math.max(80, bubbleMaxW - innerPad * 2);

            StaticLayout sl = StaticLayout.Builder
                    .obtain(currentLine, 0, currentLine.length(), textPaint, textW)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(2f * density, 1.05f)
                    .build();

            float titleH = 15f * density;
            float bw = bubbleMaxW;
            float bh = innerPad * 2 + titleH + sl.getHeight();

            float bx = (mx + mw * 0.5f) - bw * 0.5f;
            float by = my - bh - 6f * density;
            float minMargin = 10f * density;
            if (bx < minMargin) bx = minMargin;
            if (bx + bw > w - minMargin) bx = w - minMargin - bw;
            if (by < 26f * density) by = my + mh + 6f * density;
            if (by + bh > h - minMargin) by = h - minMargin - bh;

            float shakeX = (float) Math.sin(tripTime * 22f) * 2.2f * density;
            bubbleRect.set(bx + shakeX, by, bx + bw + shakeX, by + bh);

            float rad = 12f * density;
            canvas.drawRoundRect(bubbleRect, rad, rad, bubbleBgPaint);
            bubbleStrokePaint.setColor(pulse > 0.5f ? 0xFFFF00AA : 0xFF00FF66);
            canvas.drawRoundRect(bubbleRect, rad, rad, bubbleStrokePaint);

            canvas.drawText("МИКА • ГОТ-АЛЬТУШКА ✝", bubbleRect.left + innerPad, bubbleRect.top + innerPad + 9.5f * density, titlePaint);

            canvas.save();
            canvas.translate(bubbleRect.left + innerPad, bubbleRect.top + innerPad + titleH);
            sl.draw(canvas);
            canvas.restore();
        }
    }
}
