# MikaRace 3D v3.5

Универсальный Android WebView проект (Tensor / Snapdragon / MediaTek) со встроенной сборкой APK.
